---
"gradio": patch
---

fix:Catch OSErrors in `HuggingFaceDatasetSaver._deserialize_components`
