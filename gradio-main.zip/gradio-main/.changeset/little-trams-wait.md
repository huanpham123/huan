---
"@gradio/json": minor
"gradio": minor
---

feat:Add height param to gr.JSON
