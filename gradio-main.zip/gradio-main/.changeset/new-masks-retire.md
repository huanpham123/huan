---
"@gradio/chatbot": minor
"@gradio/code": minor
"gradio": minor
---

feat:Add copy all messages button to chatbot
