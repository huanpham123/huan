---
"gradio": patch
---

fix:Deal with OAuth too many redirects
