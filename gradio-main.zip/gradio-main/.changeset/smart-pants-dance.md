---
"gradio": patch
---

fix:Fix chatinterface multimodal bug
