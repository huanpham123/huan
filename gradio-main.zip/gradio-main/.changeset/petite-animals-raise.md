---
"@gradio/dataset": patch
"gradio": patch
---

fix:Reset `Dataset` page to 0 when samples change
