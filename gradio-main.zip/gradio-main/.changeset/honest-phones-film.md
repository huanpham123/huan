---
"@gradio/app": patch
---

feat:fix version + pkg name
