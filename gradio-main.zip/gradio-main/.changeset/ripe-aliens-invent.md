---
"gradio": patch
---

fix:Add more typing to event listeners
