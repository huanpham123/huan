---
"@gradio/dataset": patch
"gradio": patch
---

fix:Fix unexpected rendering of Dataset
