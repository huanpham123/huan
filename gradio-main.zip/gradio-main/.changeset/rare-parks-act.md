---
"@gradio/component-test": minor
---

feat:Create test app for components  / SSR testing.
