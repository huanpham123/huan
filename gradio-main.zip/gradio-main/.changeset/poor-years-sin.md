---
"@gradio/preview": minor
---

feat:Be able to set optimizeDeps options in gradio.config.js
