---
"@gradio/image": patch
"@gradio/multimodaltextbox": patch
"@gradio/upload": patch
"gradio": patch
---

feat:Allow drag and replace image in `gr.Image` and Multimodal textbox
