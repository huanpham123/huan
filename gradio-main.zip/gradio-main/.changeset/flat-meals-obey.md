---
"@gradio/app": minor
"@gradio/wasm": minor
"gradio": minor
---

feat:Initialize the client with the fake host for Lite server
