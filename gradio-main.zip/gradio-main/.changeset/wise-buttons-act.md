---
"@gradio/audio": patch
"@gradio/build": patch
"@gradio/button": patch
"@gradio/chatbot": patch
"@gradio/core": patch
"@gradio/dataframe": patch
"@gradio/lite": patch
"@gradio/plot": patch
"@gradio/spa": patch
"@gradio/storybook": patch
"@gradio/video": patch
"@gradio/wasm": patch
"@gradio/app": patch
"gradio": patch
"website": patch
---

feat:Initial SSR refactor
