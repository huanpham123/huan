---
"gradio": patch
---

fix:Set non-zero exit codes for custom component build and install commands when failures occur
