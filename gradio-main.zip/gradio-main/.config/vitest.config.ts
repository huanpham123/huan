import config from "../js/spa/vite.config";

export default config;
