from hatchling.builders.wheel import WheelBuilder


class LiteBuilder(WheelBuilder):
    PLUGIN_NAME = 'lite'