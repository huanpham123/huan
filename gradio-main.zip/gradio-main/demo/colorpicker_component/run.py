import gradio as gr

with gr.Blocks() as demo:
    gr.ColorPicker()

demo.launch()
