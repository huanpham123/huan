import gradio as gr

with gr.Blocks() as demo:
   gr.Button()

demo.launch()
