import gradio as gr

with gr.Blocks() as demo:
    gr.Image()

demo.launch()
